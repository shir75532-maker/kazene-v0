# kazene-v0
This is a sample Next.js project for Kazene.