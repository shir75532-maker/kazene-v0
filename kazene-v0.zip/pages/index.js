export default function Home() {
  return <h1>Welcome to kazene-v0</h1>;
}
